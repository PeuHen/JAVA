package br.com.app;
import java.util.Scanner;

import br.com.classes.*;
	

	public class App {
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			//IMPORT CLASS
				Estoque estoque = new Estoque();
				Usuario usuario = new Usuario();
				Scanner campo = new Scanner(System.in);
				Adm adm = new Adm();
				Pecas pecas = new Pecas();


//Criacao do algoritimo


				System.out.println("Digite seu User");
				usuario.nome = campo.nextLine(); 
				System.out.println("============Senha===============");
				System.out.println("Digite sua Senha:");
				usuario.senha = campo.nextLine();
				System.out.println("confirmar senha");
				usuario.senha = campo.nextLine();
				System.out.println("Senha Registrada: "+ usuario.senha);
				
				//Estoque
				System.out.println("============Estoque===============");
				
				System.out.println("Digite o nome do produto");
				estoque.nome = campo.nextLine();
				
				System.out.println("Digite a quantidade do produto");
				estoque.adicionarpeca = campo.nextDouble();
				
				System.out.println("============Informacão do estoque===============");
				
				System.out.println("Usuario Que add ao estoque:" + usuario.nome);
				System.out.println("Nome do Produto:" + estoque.nome);
				System.out.println("Quantidade em Estoque:" + estoque.adicionarpeca);
				
				

				
				
			
		}
	}
