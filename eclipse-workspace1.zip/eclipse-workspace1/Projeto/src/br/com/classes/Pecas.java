package br.com.classes;

public class Pecas  {
	public String nome;
}
