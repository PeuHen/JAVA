package br.com.classes;

public class Estoque extends Pecas{
	public double adicionarpeca;
	public double V;
}


