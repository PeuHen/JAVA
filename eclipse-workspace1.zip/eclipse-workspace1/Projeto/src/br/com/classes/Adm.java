package br.com.classes;

public class Adm extends Usuario {
	public void senha() {
		
	}
}
