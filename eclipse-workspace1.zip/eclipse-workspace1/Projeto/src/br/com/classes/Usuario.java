package br.com.classes;

public class Usuario {
	public String nome;
	public String senha;
	public String autent;
}
