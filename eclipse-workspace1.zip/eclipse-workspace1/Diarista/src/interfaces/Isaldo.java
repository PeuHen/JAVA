package interfaces;


public interface Isaldo {

	
	// todo atributo e metodo em uma interfarce é public
	void sacar (double valor); //clasulas 
	
	void depositar (double valor );
	
	
	
	
	
}
