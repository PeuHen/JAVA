package br.com.classes;

public class Diarista extends Pessoa{
	//chave pix
	
	
@Override
	public void depositar(double valor) {
		// TODO Auto-generated method stub
		
	}

}

	@Override
public void sacar(double valor) {
		// TODO Auto-generated method stub
		
	}
}
